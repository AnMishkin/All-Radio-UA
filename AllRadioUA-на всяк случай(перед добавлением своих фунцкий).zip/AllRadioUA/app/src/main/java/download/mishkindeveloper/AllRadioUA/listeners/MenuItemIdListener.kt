package download.mishkindeveloper.AllRadioUA.listeners

interface MenuItemIdListener {
    fun getItemMenu(id: Int?)
    fun updateCountOpenItem(id:Int?)
}