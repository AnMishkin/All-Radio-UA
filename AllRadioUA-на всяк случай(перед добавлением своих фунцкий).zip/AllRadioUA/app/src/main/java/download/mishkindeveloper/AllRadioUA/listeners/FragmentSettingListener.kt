package download.mishkindeveloper.AllRadioUA.listeners

interface FragmentSettingListener {
    fun update()
    fun search(textSearch: String?)
}