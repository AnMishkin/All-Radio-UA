package download.mishkindeveloper.AllRadioUA.enums

enum class DisplayListType {
    List, Grid
}